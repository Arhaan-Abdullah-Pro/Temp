package com.example.instagram_clone.utils

const val USER_NODE= "User"
const val USER_PROFILE_FOLDER= "Profile"
const val POST_FOLDER= "PostImages"
const val REEL_FOLDER= "Reel"
const val POST= "Post"
const val REEL = "Reel"